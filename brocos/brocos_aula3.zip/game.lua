module(...,package.seeall)
---------------------------
local physics = require "physics"
physics.setGravity(9.8)
physics.setDrawMode("hybrid")
physics.start()
---------------------------
local fonts = {neuropol = "Neuropol"}

function new()
	local game = display.newGroup()
	game.score = 0
	
	game.show = function(game)
		game.background = display.newRect(game,0,0,
			display.contentWidth,display.contentHeight)
		game.background:setFillColor(23,134,45)

		game.scoreTitleText = display.newText(game,"Score:",
			20,20,fonts.neuropol,25)
		game.scoreTitleText:setTextColor(0,0,0)
				
		game.scoreValueText = display.newText(game,game.score,
			game.scoreTitleText.x + game.scoreTitleText.width,
			20,fonts.neuropol,25)
		game.scoreValueText:setTextColor(0,0,0)
		
		for j=1,6 do			
			for i=1,display.contentWidth/32 do
				local block = display.newImage(game,
					"square_"..math.random(1,4)..".png",
					(32*(i-1)),80+(32*(j-1)))
				physics.addBody(block,"static",
					{density=1,friction=0.3,bounce=0})
			end
		end		
		
		game.bar = display.newImage(game,"bar.png",
			display.contentWidth/2,display.contentHeight)
		game.bar.x = game.bar.x - game.bar.width/2
		game.bar.y = game.bar.y - game.bar.width
		
		physics.addBody(game.bar,"static",
			{density=1,friction=.3,bounce=0})
		
		game.ball = display.newImage(game,"ball.png",
			display.contentWidth/2,
			game.bar.y)
		game.ball.x = game.ball.x - game.ball.width/2
		game.ball.y = game.ball.y - game.ball.width - 10
		
		physics.addBody(game.ball,"dynamic",
			{density=1,friction=.3,bounce=0,radius=10})
		
		local leftWall = display.newRect(game,-1,0,1,
			display.contentHeight)
		leftWall:setFillColor(0,0,0,0)
		physics.addBody(leftWall, "static", 
			{density=1, friction=1, bounce=0})
		
		local rightWall = display.newRect(game,
			display.contentWidth,0,1,
			display.contentHeight)
		rightWall:setFillColor(0,0,0,0)
		physics.addBody(rightWall, "static", {density=1, 
			friction=.3, bounce=0})
		
		local roof = display.newRect(game,0,-1,
			display.contentWidth,1)
		roof:setFillColor(0,0,0,0)
		physics.addBody(roof, "static", {density=1, 
			friction=.3, bounce=0})
		
		local flor = display.newRect(game,
			0,display.contentHeight,display.contentWidth,
			1)
		flor:setFillColor(0,0,0,0)
		physics.addBody(flor, "static",
			{density=1, friction=.3, bounce=0})
	end
	
	return game
end