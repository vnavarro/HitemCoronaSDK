display.setStatusBar(display.HiddenStatusBar)
-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------
local menuControl = require "menu"
local gameScreen = require "game"
-----------
function start()
	local menuPrincipal = menuControl.new()
	local game = gameScreen.new()
	game:show()
end
start()











