application = {
	content = {
		width = 480,
		height = 854, 
		scale = "letterBox",
		fps = 30,
		
		--[[
		imageSuffix = {
		    ["@2x"] = 2,
		}
		--]]
	}
}